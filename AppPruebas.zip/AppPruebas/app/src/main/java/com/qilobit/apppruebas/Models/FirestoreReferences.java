package com.qilobit.apppruebas.Models;

public class FirestoreReferences {
    public static String PEOPLE = "People";
}
